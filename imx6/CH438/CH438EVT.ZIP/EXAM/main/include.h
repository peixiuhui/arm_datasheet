#include<reg52.h>
#include<stdio.h>
#include"CH438INC.H"

//#include".\AtlerAddr\AtlerAddr.h"     /* Ӳ���ӿڲ�ͷ�ļ� ��ַ���� */
#include".\DirectAddr\DirectAddr.h"	/* Ӳ���ӿڲ�ͷ�ļ� ֱ�ӵ�ַ */
#include".\CH438UART\CH438UART0.H"
#include".\CH438UART\CH438UART1.H"
#include".\CH438UART\CH438UART2.H"
#include".\CH438UART\CH438UART3.H"
#include".\CH438UART\CH438UART4.H"
#include".\CH438UART\CH438UART5.H"
#include".\CH438UART\CH438UART6.H"
#include".\CH438UART\CH438UART7.H"

