This archive contains the following files for EVB-USB2514QFN48 (Makuwa), Rev. A:

All gerber files are in RS274-X format, 3.5 Absolute English
All NCD files are in Excellon format, 3.5 Absolute English


README.TXT 		- This ASCII note file

EVB-USB2514QFN48_A-ipc.net	- The IPC netlist for this Gerber Set

TOP.PHO    		- Top trace layer gerber
IN2.PHO			- Inner layer 2 gerber
IN3.PHO			- Inner layer 3 gerber
BOT.PHO 	   	- Bottom trace layer gerber
TSM.PHO    		- Top soldermask gerber
BSM.PHO  	  	- Bottom soldermask gerber
TSK.PHO    		- Top silkscreen gerber
FAB.PHO   	 	- Fabrication drawing gerber

NCD.DRL    		- NCD file 
NCD.REP    		- NCD tool size
NCD.LST   		- ASCII NCD file

TPS.PHO   	 	- Top paste stencil gerber

Contact the engineer below for Fabrication questions or comments.

Carl Johnson
SMSC
(512) 418-2239
carl.johnson@smsc.com